package com.carlos.leitorpdf; // troque pelo pacote do seu projeto no Sketchware Pro

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.webkit.JavascriptInterface;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Ponte entre o WebView (leitor-pdf-nativo.html) e o Android nativo.
 *
 * Registro no código da Activity (na tela onde está o WebView):
 *
 *   webView.getSettings().setJavaScriptEnabled(true);
 *   webView.addJavascriptInterface(new MediaPdfBridge(this), "AndroidPDF");
 *   webView.loadUrl("file:///android_asset/leitor-pdf-nativo.html");
 *
 * No Sketchware Pro, isso normalmente é feito através de um bloco de
 * "código customizado" / "extra Java" dentro do evento onCreate da tela,
 * já que a interface gráfica de blocos não tem um botão pronto para
 * addJavascriptInterface.
 */
public class MediaPdfBridge {

    private final Context context;

    public MediaPdfBridge(Context context) {
        this.context = context;
    }

    /**
     * Varre o armazenamento do aparelho (MediaStore) por arquivos PDF.
     * Retorna uma String JSON no formato:
     * [{"uri":"content://...","name":"arquivo.pdf","size":12345}, ...]
     *
     * Requer permissão de leitura de armazenamento concedida em tempo de
     * execução (ver nota sobre permissões no final do arquivo).
     */
    @JavascriptInterface
    public String listPdfs() {
        JSONArray result = new JSONArray();
        String[] projection = {
                MediaStore.Files.FileColumns._ID,
                MediaStore.Files.FileColumns.DISPLAY_NAME,
                MediaStore.Files.FileColumns.SIZE
        };
        String selection = MediaStore.Files.FileColumns.MIME_TYPE + "=?";
        String[] selectionArgs = {"application/pdf"};

        Uri collection = MediaStore.Files.getContentUri("external");

        try (Cursor cursor = context.getContentResolver().query(
                collection, projection, selection, selectionArgs, null)) {

            if (cursor != null) {
                int idCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID);
                int nameCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME);
                int sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE);

                while (cursor.moveToNext()) {
                    long id = cursor.getLong(idCol);
                    String name = cursor.getString(nameCol);
                    long size = cursor.getLong(sizeCol);
                    Uri fileUri = Uri.withAppendedPath(collection, String.valueOf(id));

                    JSONObject obj = new JSONObject();
                    try {
                        obj.put("uri", fileUri.toString());
                        obj.put("name", name);
                        obj.put("size", size);
                        result.put(obj);
                    } catch (Exception ignored) {}
                }
            }
        } catch (Exception e) {
            Log.e("MediaPdfBridge", "erro ao consultar MediaStore", e);
        }

        return result.toString();
    }

    /**
     * Lê o conteúdo de um PDF a partir da URI retornada por listPdfs()
     * e devolve em Base64, pronto para o JS reconstruir como Blob.
     */
    @JavascriptInterface
    public String readPdfBytes(String uriString) {
        try {
            Uri uri = Uri.parse(uriString);
            InputStream in = context.getContentResolver().openInputStream(uri);
            if (in == null) return "";

            ByteArrayOutputStream buffer = new ByteArrayOutputStream();
            byte[] chunk = new byte[8192];
            int bytesRead;
            while ((bytesRead = in.read(chunk)) != -1) {
                buffer.write(chunk, 0, bytesRead);
            }
            in.close();

            return Base64.encodeToString(buffer.toByteArray(), Base64.NO_WRAP);
        } catch (Exception e) {
            Log.e("MediaPdfBridge", "erro ao ler PDF", e);
            return "";
        }
    }
}

/*
 * PERMISSÕES NECESSÁRIAS (AndroidManifest.xml):
 *
 * <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE"
 *     android:maxSdkVersion="32" />
 * <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />
 * <uses-permission android:name="android.permission.MANAGE_EXTERNAL_STORAGE" />
 *
 * A partir do Android 11 (API 30), pra varrer TODOS os PDFs do
 * armazenamento (não só os que o próprio app criou), é preciso pedir a
 * permissão especial "Acesso a todos os arquivos", que só pode ser
 * concedida manualmente pelo usuário numa tela de configurações:
 *
 *   Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
 *   intent.setData(Uri.parse("package:" + context.getPackageName()));
 *   context.startActivity(intent);
 *
 * Sem isso, listPdfs() ainda funciona, mas só enxerga PDFs que já passaram
 * pelo picker do próprio app (comportamento parecido com o antigo).
 */
